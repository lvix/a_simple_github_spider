# -*- coding: utf-8 -*-
from datetime import datetime 
from sqlalchemy.orm import sessionmaker
from ScrLab3.models import User, engine
# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: http://doc.scrapy.org/en/latest/topics/item-pipeline.html

    
class Scrlab3Pipeline(object):
    def process_item(self, item, spider):
        item['level'] = int(item['level'])
        item['learn_courses_num'] = int(item['learn_courses_num'])
        item['join_date'] = datetime.strptime(item['join_date'], '%Y-%m-%d')
        self.session.add(User(**item))
        return item

    def open_spider(self, siper):
        '''
        called when spider being opened
        '''
        # print('============================================')
        Session = sessionmaker(bind=engine)
        self.session = Session()

    def close_spider(self, spider):
        '''
        called when sipder is being closed 
        '''
        # print('close spider')
        self.session.commit()
        self.session.close()