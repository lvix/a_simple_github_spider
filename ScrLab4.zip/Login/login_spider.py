# -*- coding: utf-8 -*-
import scrapy

class LoginSpiderSpider(scrapy.Spider):
    name = 'login_spider'
    start_urls = ['https://www.shiyanlou.com/login']

    def parse(self, response):

        csrf_token = response.xpath('//div[@class="login-body"]//input[@id="csrf_token"]/@value').extract_first()
        return scrapy.FormRequest.from_response(
            response,
            formdata={
                'csrf_token': csrf_token, 
                'login': 'example@exapmle.com',
                'password': 'password',
            },
            callback=self.after_login
            )

    def after_login(self, response):
        return [scrapy.Request(
            url='https://www.shiyanlou.com/user/566212/',
            callback=self.parse_after_login
            )]

    def parse_after_login(self, response):
        return {
            'lab_count':response.xpath('/html/body/div[4]/div/div/div[2]/div/div[1]/div[1]/div/table/tbody/tr[2]/td[2]/span/text()').re_first('[^\d]*(\d*)[^\d*]'),
            'lab_minutes': response.xpath('/html/body/div[4]/div/div/div[2]/div/div[1]/div[1]/div/table/tbody/tr[3]/td[2]/span/text()').re_first('[^\d]*(\d*)[^\d*]')
            }
        
        
